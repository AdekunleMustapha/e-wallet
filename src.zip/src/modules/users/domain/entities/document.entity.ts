import { ValidationError } from "src/shared/domain/errors";
import { BaseEntity } from "src/shared/domain/base-entity";
import { Result } from "src/shared/domain/result";
import { UniqueId } from "src/shared/domain/unique-id";

type DocumentProps = {
    id?: UniqueId;
    personId: UniqueId;
    documentTypeId: UniqueId;
    documentName: string;
    documentLink: string;
    verified: boolean;
    createdAt?: Date;
    updatedAt?: Date;
}

/**
 * Document Entity, keeps track of user submitted docs
 * By their types, their links and if they are verified
 */
export class Document extends BaseEntity {
    private _personId: UniqueId;
    private _documentTypeId: UniqueId;
    private _documentName: string;
    private _documentLink: string;
    private _verified: boolean;

    private constructor(props: DocumentProps) {
        super({
            id: props.id,
            createdAt: props.createdAt,
            updatedAt: props.updatedAt
        });
        this._personId = props.personId;
        this._documentTypeId = props.documentTypeId;
        this._documentName = props.documentName;
        this._documentLink = props.documentLink;
        this._verified = props.verified;
    }

    public static create (props: DocumentProps): Result<Document> {
        const documentName = props.documentName.trim();
        if(documentName.length === 0 || documentName.length > 255) {
            return Result.fail(new ValidationError("Document name should be between 1 to 255 characters"));
        }

        return Result.ok(new Document({
            documentLink: props.documentLink.trim(),
            documentName: documentName,
            documentTypeId: props.documentTypeId,
            personId: props.personId,
            verified: false // documents are not verified by default
        }));
    }

    public static reconstitute(props: DocumentProps): Document {
        return new Document(props);
    }

    public update(props: {
        documentName?: string;
        documentTypeId?: UniqueId;
        verified?: boolean;
    }): Result<void> {
        if (props.documentName !== undefined) {
            const documentName = props.documentName.trim();
            if (documentName.length === 0 || documentName.length > 255) {
                return Result.fail(new ValidationError("Document name should be between 1 to 255 characters"));
            }
            this._documentName = documentName;
        }

        if (props.documentTypeId !== undefined) {
            this._documentTypeId = props.documentTypeId;
        }

        if(props.verified !== undefined) {
            if(this._verified === true && props.verified === false) {
                return Result.fail(new ValidationError("A verified document can't be made unverified"));
            }
            this._verified = true;
        }

        this.updateTimestamp();
        return Result.ok();
    }

    get documentLink(): string {return this._documentLink;}

    get documentName(): string {return this._documentName;}

    get documentTypeId(): UniqueId {return this._documentTypeId;}

    get personId(): UniqueId {return this._personId;}

    get verified(): boolean {return this._verified;}
}
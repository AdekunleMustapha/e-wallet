import { IsEnum, IsOptional, IsString } from "class-validator";
import { PaginationRequest } from "./pagination.request";
import { Country, NigeriaState } from "../../domain/enums";

export class SearchCityRequest extends PaginationRequest {
    @IsOptional()
    @IsString()
    city?: string;

    @IsOptional()
    @IsEnum(NigeriaState)
    state?: NigeriaState;

    @IsOptional()
    @IsEnum(Country)
    country?: Country;
}
